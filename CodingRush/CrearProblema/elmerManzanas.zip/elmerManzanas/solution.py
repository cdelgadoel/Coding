n = int(input())

suma = 0
for i in range(n):
  suma += int(input())
print(suma)