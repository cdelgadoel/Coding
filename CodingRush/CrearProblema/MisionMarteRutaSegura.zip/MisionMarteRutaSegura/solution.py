def can_reach_destination(matrix, n, m):
    # Encontrar las posiciones iniciales de 'M'
    start = None
    for i in range(n):
        for j in range(m):
            if matrix[i][j] == 'M':
                start = (i, j)
                break
        if start:
            break
    
    # Direcciones de movimiento permitidas (arriba, abajo, izquierda, derecha)
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    # Cola para la búsqueda en anchura
    dfs = [start]
    # Conjunto para mantener registro de las celdas visitadas
    visited = set()
    visited.add(start)
    
    while dfs:
        current = dfs.pop()
        x, y = current
        
        # Verificar si el destino es alcanzado
        if matrix[x][y] == 'D':
            return "EUREKA"
        
        # Explorar las cuatro direcciones posibles
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            if 0 <= nx < n and 0 <= ny < m and (nx, ny) not in visited and matrix[nx][ny] != 'X':
                visited.add((nx, ny))
                dfs.append((nx, ny))
    
    return "SEND HELP"

def main():
    n, m = map(int, input().split())
    matrix = []
    for _ in range(n):
        matrix.append(input())

    print(can_reach_destination(matrix, n, m))

if __name__ == "__main__":
    main()
